
public class EducatorModel //extends IModel 
{
	
	public String generateQuestions() {
		return null;
	}
	
	public String generateChoices() {
		return null;
	}
	
	public boolean checkAnswer() {
		return false;
	}
	
	public static void main(String[] args) {
		
	}

}
