import javax.swing.JFrame;

import java.awt.Graphics;

import javax.swing.JButton;  

public class EducatorView // extends IView 
{
	
	int xloc = 0;
	int yloc = 0;
	
	JFrame jFrame = new JFrame();
	
	public enum Direction {
		
	}
	
	
	public void paint(Graphics g) {
		
	}
	
	public void update(int x, int y, Direction d) {
		
	}
	
	public void displayResult() {
		
	}
	
	public void displayScore() {
		
	}

	public static void main(String[] args) {
	
	JButton Selection1 = new JButton("Click");
	
	JButton Selection2 = new JButton("Click");
	
	JButton Selection3 = new JButton("Click");
	
	
	}
	
}
